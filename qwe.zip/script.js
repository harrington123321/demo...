// Page Navigation
function showPage(page) {
    clearMessages();
    if (page === 'about') {
      showAbout();
    } else if (page === 'contact') {
      showContact();
    } else if (page === 'courses') {
      showCourses();
    } else if (page === 'login') {
      showLogin();
    }
  }
  
  // Utility to clear messages
  function clearMessages() {
    const msgElems = document.querySelectorAll('.message');
    msgElems.forEach(el => el.textContent = '');
  }
  
  // Show About Section
  function showAbout() {
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <h2>About Us</h2>
      <p>Welcome to My Synergy Classes where you can find best courses.</p>
      <p>We offer top quality coaching to help you succeed in your exams and career.</p>
    `;
  }
  
  // Show Contact Section with simple form
  function showContact() {
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <h2>Contact Us</h2>
      <form id="contactForm">
        <label for="name">Name:</label><br/>
        <input type="text" id="name" name="name" required /><br/>
        
        <label for="email">Email:</label><br/>
        <input type="email" id="email" name="email" required /><br/>
        
        <label for="message">Message:</label><br/>
        <textarea id="message" name="message" rows="4" required></textarea><br/>
        
        <button type="submit">Send</button>
        <p class="message" id="contact-msg"></p>
      </form>
    `;
  
    document.getElementById('contactForm').addEventListener('submit', function(e) {
      e.preventDefault();
      document.getElementById('contact-msg').textContent = "Thank you for contacting us!";
      this.reset();
    });
  }
  
  // Show Courses List
  function showCourses() {
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <h2>Our Courses</h2>
      <div class="course-item">
        <h3>Physics Basics</h3>
        <p>Understand fundamentals of Physics.</p>
      </div>
      <div class="course-item">
        <h3>Mathematics Essentials</h3>
        <p>Learn essential math concepts.</p>
      </div>
      <div class="course-item">
        <h3>Chemistry Basics</h3>
        <p>Introduction to Chemistry concepts.</p>
      </div>
    `;
  }
  
  // --------- Authentication Logic ------------
  
  function getUsers() {
    return JSON.parse(localStorage.getItem('users') || '{}');
  }
  
  function saveUser(username, password) {
    const users = getUsers();
    users[username] = password;  // Warning: Not secure, for demo only
    localStorage.setItem('users', JSON.stringify(users));
  }
  
  function checkLogin(username, password) {
    const users = getUsers();
    return users[username] && users[username] === password;
  }
  
  function showLogin() {
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <h2>Login</h2>
      <input id="login-username" placeholder="Username" /><br/>
      <input type="password" id="login-password" placeholder="Password" /><br/>
      <button onclick="login()">Login</button>
      <p class="message" id="login-msg"></p>
      <p>Don't have an account? <a href="#" onclick="showRegister()">Register here</a></p>
    `;
  }
  
  function showRegister() {
    const main = document.getElementById('main-content');
    main.innerHTML = `
      <h2>Register</h2>
      <input id="register-username" placeholder="Username" /><br/>
      <input type="password" id="register-password" placeholder="Password" /><br/>
      <button onclick="register()">Register</button>
      <p class="message" id="register-msg"></p>
      <p>Already have an account? <a href="#" onclick="showLogin()">Login here</a></p>
    `;
  }
  
  function login() {
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
  
    if (!username || !password) {
      document.getElementById('login-msg').textContent = "Both fields are required.";
      return;
    }
  
    if (checkLogin(username, password)) {
      localStorage.setItem('sessionUser', username);
      updateAuthUI();
      showCourses();
    } else {
      document.getElementById('login-msg').textContent = "Invalid username or password.";
    }
  }
  
  function register() {
    const username = document.getElementById('register-username').value.trim();
    const password = document.getElementById('register-password').value;
  
    if (username.length < 3 || password.length < 3) {
      document.getElementById('register-msg').textContent = "Minimum 3 characters required.";
      return;
    }
  
    const users = getUsers();
    if (users[username]) {
      document.getElementById('register-msg').textContent = "Username already exists!";
      return;
    }
  
    saveUser(username, password);
    document.getElementById('register-msg').textContent = "Registration successful! Please login.";
    setTimeout(showLogin, 1500);
  }
  
  function logout() {
    localStorage.removeItem('sessionUser');
    updateAuthUI();
    showAbout();
  }
  
  function updateAuthUI() {
    const sessionUser = localStorage.getItem('sessionUser');
    const authLinks = document.getElementById('auth-links');
    const userInfo = document.getElementById('user-info');
    const welcomeMsg = document.getElementById('welcome-msg');
  
    if (sessionUser) {
      authLinks.style.display = 'none';
      userInfo.style.display = 'inline';
      welcomeMsg.textContent = `Welcome, ${sessionUser}`;
    } else {
      authLinks.style.display = 'inline';
      userInfo.style.display = 'none';
      welcomeMsg.textContent = '';
    }
  }
  
  // On page load
  document.addEventListener('DOMContentLoaded', () => {
    updateAuthUI();
    showAbout();
  });
  